npm i
pause