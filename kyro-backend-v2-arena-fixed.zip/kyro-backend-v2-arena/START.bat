@echo off
cd /d "%~dp0"
title Kyro Backend
color 0B
echo.
echo  ================================
echo   Kyro Backend
echo   Discord OAuth Login
echo  ================================
echo.

:: Start MongoDB service
sc query MongoDB | find "RUNNING" >nul 2>&1
if %errorlevel% equ 0 (
    echo  MongoDB already running.
    goto startbackend
)

echo  Starting MongoDB service...
net start MongoDB >nul 2>&1
if %errorlevel% equ 0 (
    echo  MongoDB started.
    goto startbackend
)

:: Try to find mongod.exe automatically
for /d %%v in ("C:\Program Files\MongoDB\Server\*") do set MONGO_PATH=%%v\bin\mongod.exe
if exist "%MONGO_PATH%" (
    echo  Starting MongoDB manually from %MONGO_PATH%...
    if not exist "%~dp0data" mkdir "%~dp0data"
    start /min "" "%MONGO_PATH%" --dbpath "%~dp0data" --port 27017
    timeout /t 3 /nobreak >nul
    echo  MongoDB started.
) else (
    echo  [WARNING] MongoDB not found - backend may fail to connect.
)

:startbackend
echo  Starting Kyro Backend on port 8080...
echo.
node index.js
pause
